const Curso = require('../models/Cursos');

const CursoService = {
    async listarCursos() {
        /* Equivale: SELECT * FROM cursos */
        const cursos = await Curso.findAll();
        return cursos;
    }   
}

module.exports = CursoService;
